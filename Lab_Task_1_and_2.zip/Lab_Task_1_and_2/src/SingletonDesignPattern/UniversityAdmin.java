/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SingletonDesignPattern;

/**
 *
 * @author TechEnclave Computer
 */
class UniversityAdmin {

    private static UniversityAdmin instance;
    private UniversityAdmin() {
    }
    public static UniversityAdmin getInstance() {
        if (instance == null) {
            instance = new UniversityAdmin();
        }
        return instance;
    }
    public void manageStudents() {
        System.out.println("Admin Managing Students....");
    }

    public void manageCourses() {
        System.out.println("Admin Managing Courses.....");
    }

    public void generateReports() {
        System.out.println("Admin Generating Reports....");
    }
}
