/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principles;

/**
 *
 * @author TechEnclave Computer
 */
// Abstract base class for university staff members
abstract class Staff {
    public abstract String getRole();
}

// Concrete implementation for a professor
class Professor extends Staff {
    @Override
    public String getRole() {
        return "Professor";
    }
}

// Concrete implementation for administrative staff
class AdministrativeStaff extends Staff {
    @Override
    public String getRole() {
        return "Administrative Staff";
    }
}

// Factory interface
interface StaffFactory {
    Staff createStaff();
}

// Concrete factory for creating professors
class ProfessorFactory implements StaffFactory {
    @Override
    public Staff createStaff() {
        return new Professor();
    }
}

// Concrete factory for creating administrative staff
class AdministrativeStaffFactory implements StaffFactory {
    @Override
    public Staff createStaff() {
        return new AdministrativeStaff();
    }
}


