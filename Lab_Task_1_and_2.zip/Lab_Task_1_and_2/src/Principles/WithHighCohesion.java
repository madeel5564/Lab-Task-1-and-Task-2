/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principles;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author TechEnclave Computer
 */
// High cohesion: ShoppingCart class that handles shopping-related operations
class ShoppingCart {
    private List<String> items = new ArrayList<>();

    public void addItem(String item) {
        items.add(item);
        System.out.println(item + " added to the cart.");
    }

    public void removeItem(String item) {
        if (items.contains(item)) {
            items.remove(item);
            System.out.println(item + " removed from the cart.");
        } else {
            System.out.println(item + " not found in the cart.");
        }
    }

    public void checkout() {
        System.out.println("Checkout complete. Thank you for shopping!");
    }

    public void viewCart() {
        System.out.println("Items in the cart:");
        for (String item : items) {
            System.out.println("- " + item);
        }
    }
}

