/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principles;

/**
 *
 * @author TechEnclave Computer
 */
interface ControllableDevice {
    void turnOn();
    void turnOff();
}

// Concrete implementation for a TV
class TV implements ControllableDevice {
    @Override
    public void turnOn() {
        System.out.println("TV is turned on");
    }

    @Override
    public void turnOff() {
        System.out.println("TV is turned off");
    }
}

// Concrete implementation for a Stereo
class Stereo implements ControllableDevice {
    @Override
    public void turnOn() {
        System.out.println("Stereo is turned on");
    }

    @Override
    public void turnOff() {
        System.out.println("Stereo is turned off");
    }
}

// Remote control class that uses indirection
class RemoteControl {
    private ControllableDevice device;

    public RemoteControl(ControllableDevice device) {
        this.device = device;
    }

    public void pressPowerButton() {
        // Use indirection to control the device
        device.turnOn();
    }

    public void pressPowerOffButton() {
        // Use indirection to turn off the device
        device.turnOff();
    }
}