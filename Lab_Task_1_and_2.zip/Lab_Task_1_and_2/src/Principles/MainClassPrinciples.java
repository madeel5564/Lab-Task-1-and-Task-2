/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Principles;

/**
 *
 * @author TechEnclave Computer
 */
public class MainClassPrinciples {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
               System.out.println("\nPrinciple 1 - Creator \n");
               
               StaffFactory professorFactory = new ProfessorFactory();
               Staff professor = professorFactory.createStaff();
               System.out.println("Created " + professor.getRole());
               StaffFactory adminStaffFactory = new AdministrativeStaffFactory();
               Staff adminStaff = adminStaffFactory.createStaff();
               System.out.println("Created " + adminStaff.getRole());
               
               System.out.println("\nPrinciple 2 - Polymorphisam \n");
               
                Animal[] animals = new Animal[3];
                animals[0] = new Dog("Buddy");
                animals[1] = new Cat("Whiskers");
                animals[2] = new Dog("Rex");
                for (Animal animal : animals) 
                {
                    animal.makeSound();
                }
                
               System.out.println("\nPrinciple 3 - Abstraction \n");
               
                Circle circle = new Circle(5.0);
                Rectangle rectangle = new Rectangle(4.0, 6.0);

                // Calculate and print the area and perimeter of each shape
                System.out.println("Circle Area: " + circle.calculateArea());
                System.out.println("Circle Perimeter: " + circle.calculatePerimeter());

                System.out.println("Rectangle Area: " + rectangle.calculateArea());
                System.out.println("Rectangle Perimeter: " + rectangle.calculatePerimeter());
               
               System.out.println("\nPrinciple 4 - Indirection \n");
               
                TV tv = new TV();
                Stereo stereo = new Stereo();

                // Create remote controls for the devices
                RemoteControl tvRemote = new RemoteControl(tv);
                RemoteControl stereoRemote = new RemoteControl(stereo);

                // Use the remote controls to interact with the devices indirectly
                tvRemote.pressPowerButton();
                stereoRemote.pressPowerButton();
                tvRemote.pressPowerOffButton();
                stereoRemote.pressPowerOffButton();
               
               System.out.println("\nPrinciple 5 - High Coesion \n");
               
                 ShoppingCart cart = new ShoppingCart();
                 cart.addItem("Product A");
                 cart.addItem("Product B");
                 cart.viewCart();
                 cart.removeItem("Product A");
                 cart.viewCart();
                 cart.checkout();
    }
    
}
